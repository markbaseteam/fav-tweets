If you're linking your Twitter profile on your website, use this link:

twitter .com/intent/user?screen_name=[YOUR_TWITTER_USERNAME]

If clicked, it shows a Follow popup which you can see in the screenshot below.

![[Pasted image 20220613082338.png]]
