Ever used Google's ping tool for faster indexing?

Google recommends sending a ping request every time pages are added/updated to this address:

google .com/ping?sitemap=FULL_URL_OF_SITEMAP

You can either do it manually or have a setup to do it automatically.

![[Pasted image 20220613082227.png]]