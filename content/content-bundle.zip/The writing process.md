This is what the writing process looks like for me...

- A Google Docs document for writing
- A Notion doc with already researched information
- A Brave browser window with several opened tabs

It's a screenshot of both my screens.

![[Pasted image 20220613081857.png]]

Looks cool, isn't it?